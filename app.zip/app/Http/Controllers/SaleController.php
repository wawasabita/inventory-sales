<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Sale;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class SaleController extends Controller
{
    public function index(Request $request)
    {
        $sales = Sale::with('user')
            ->when(! $request->user()->can('manage-master-data'), fn ($query) => $query->where('user_id', $request->user()->id))
            ->when($request->status, fn ($query, $status) => $query->where('status', $status))
            ->when($request->dari, fn ($query, $date) => $query->whereDate('sold_at', '>=', $date))
            ->when($request->sampai, fn ($query, $date) => $query->whereDate('sold_at', '<=', $date))
            ->latest('sold_at')
            ->paginate(10)
            ->withQueryString();

        return view('sales.index', compact('sales'));
    }

    public function create()
    {
        $products = Product::orderBy('name')->get();

        return view('sales.create', compact('products'));
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'items' => ['required', 'array'],
            'items.*.product_id' => ['nullable', 'exists:products,id'],
            'items.*.quantity' => ['nullable', 'integer', 'min:1'],
        ]);

        $rows = collect($data['items'])
            ->filter(fn ($row) => ! empty($row['product_id']))
            ->values();

        if ($rows->isEmpty()) {
            return back()->withInput()->withErrors(['items' => 'Pilih minimal satu produk.']);
        }

        foreach ($rows as $row) {
            if (empty($row['quantity'])) {
                return back()->withInput()->withErrors(['items' => 'Jumlah wajib diisi untuk setiap produk yang dipilih.']);
            }
        }

        $sale = DB::transaction(function () use ($rows, $request) {
            $sale = Sale::create([
                'user_id' => $request->user()->id,
                'sale_number' => $this->generateNumber(),
                'total' => 0,
                'status' => 'completed',
                'sold_at' => now(),
            ]);

            $total = 0;

            foreach ($rows as $row) {
                $product = Product::lockForUpdate()->findOrFail($row['product_id']);
                $quantity = (int) $row['quantity'];

                if ($product->stock < $quantity) {
                    throw ValidationException::withMessages([
                        'items' => "Stok {$product->name} tidak cukup. Tersedia {$product->stock}, diminta {$quantity}.",
                    ]);
                }

                $subtotal = $quantity * $product->selling_price;

                $sale->items()->create([
                    'product_id' => $product->id,
                    'quantity' => $quantity,
                    'unit_price' => $product->selling_price,
                    'subtotal' => $subtotal,
                ]);

                $product->decrement('stock', $quantity);
                $total += $subtotal;
            }

            $sale->update(['total' => $total]);

            return $sale;
        });

        return redirect()->route('sales.show', $sale)->with('status', 'Penjualan berhasil disimpan dan stok berkurang.');
    }

    public function show(Request $request, Sale $sale)
    {
        abort_unless(
            $request->user()->can('manage-master-data') || $sale->user_id === $request->user()->id,
            403
        );

        $sale->load(['user', 'items.product']);

        return view('sales.show', compact('sale'));
    }

    public function cancel(Sale $sale): RedirectResponse
    {
        try {
            DB::transaction(function () use ($sale) {
                $locked = Sale::with('items')->lockForUpdate()->findOrFail($sale->id);

                if ($locked->status !== 'completed') {
                    throw new \RuntimeException('Penjualan ini sudah dibatalkan.');
                }

                foreach ($locked->items as $item) {
                    Product::lockForUpdate()->findOrFail($item->product_id)->increment('stock', $item->quantity);
                }

                $locked->update(['status' => 'cancelled']);
            });
        } catch (\RuntimeException $e) {
            return back()->with('error', $e->getMessage());
        }

        return redirect()->route('sales.show', $sale)->with('status', 'Penjualan dibatalkan dan stok dikembalikan.');
    }

    private function generateNumber(): string
    {
        $count = Sale::whereDate('created_at', today())->count() + 1;

        return 'SAL-'.now()->format('Ymd').'-'.str_pad($count, 4, '0', STR_PAD_LEFT);
    }
}
